AIM-DSPP simulation code — Colab instructions
=============================================

1. Upload `aim_dspp_simulation_colab.py` to Google Colab.
2. Run it in the notebook kernel (recommended):

       %run /content/aim_dspp_simulation_colab.py

   You can also paste the entire script into one Colab cell and run it.

3. The full run displays every table and every figure inline.
4. It creates `AIM_DSPP_Simulation_Outputs.zip` containing:
   - 8 publication figures in PNG and PDF,
   - CSV and LaTeX tables,
   - fitted model weights,
   - compressed simulation/prediction data,
   - summary.json and config.json,
   - simulation_section_auto.tex populated from the ACTUAL run.
5. In Colab, the script attempts to start a browser download of the ZIP automatically.
   If the browser blocks it, use the Files pane to download the ZIP manually.

Full run is the default. For a quick code smoke test only:

       %env AIM_DSPP_QUICK=1
       %run /content/aim_dspp_simulation_colab.py

Then unset QUICK mode before producing paper results:

       %env AIM_DSPP_QUICK=0

Scientific safeguards
---------------------
- No model result is hard-coded.
- No benchmark is removed based on performance.
- Oracle is a reference, not a fitted competitor.
- The law-stability experiment estimates the common-PRM coupling disagreement
  E[1-exp(-D_T)], which upper-bounds total variation; it does not claim to
  estimate exact total variation.
- The universal-approximation experiment reports an empirical evaluation-set
  supremum error, not a mathematical proof of the global sup norm.
